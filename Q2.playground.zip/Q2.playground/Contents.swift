//Q2
var arrTuples: [(no: Int, name: String, age: Double)] = [(1, "Srija", 23.9), (2, "Aditya", 25.6)]
for i in arrTuples{
    print("\(i.no) ~> \(i.name) ~> \(i.age)")
}
